﻿// Write your Javascript code.

$(document).ready(function () {
    $('#table_id').DataTable();
});
